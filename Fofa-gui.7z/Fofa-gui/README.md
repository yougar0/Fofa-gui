# Fofa-gui

### Fofa采集工具

最近收集资产啥的用fofa用的比较多，搁网上找有没有好用的采集工具，发现不能满足我的部分需求，所以自己修改了一个。这里基于

https://www.t00ls.net/viewthread.php?tid=57096

吐司大佬发的源码改了一下，感谢大佬贡献的源码。

修改内容如下：

1. ListView输出ip,port,host,server,title。
2. 修改输出内容为result.csv。
3. 修改从GUI界面加载Api key。
4. 修改支持双击点击直接打开url地址。
5. ilmerge合并exe和dll。

![image-20200824134139052](https://github.com/uknowsec/Fofa-gui/blob/master/image-20200824134139052.png)



> 来自社区，回馈社区。

需要下载的可关注公众号并回复：Fofa，获取下载链接。

或直接到github下载：

https://github.com/uknowsec/Fofa-gui

